<?php

//system('start c:\foobar2000\foobar2000.exe > nul');